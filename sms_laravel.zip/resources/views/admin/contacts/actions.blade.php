<a href="{{ route('admin.contacts.village', $village->id) }}" class="btn btn-info btn-icon" title="مشاهده شماره‌ها">
    <i class="fas fa-eye"></i>
</a>