import 'bootstrap/dist/js/bootstrap.bundle.min.js';


import './bootstrap';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
