<a href="<?php echo e(route('admin.contacts.edit', $contact->id)); ?>" class="btn btn-warning btn-icon" title="ویرایش کانتکت">
    <i class="fas fa-edit"></i>
</a>
<form action="<?php echo e(route('admin.contacts.destroy', $contact->id)); ?>" method="POST" style="display:inline;">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit" class="btn btn-danger btn-icon" title="حذف کانتکت" onclick="return confirm('آیا مطمئن هستید؟')">
        <i class="fas fa-trash"></i>
    </button>
</form>
<?php /**PATH C:\xampp\htdocs\sms_laravel\resources\views/admin/contacts/contact_actions.blade.php ENDPATH**/ ?>