
<?php $__env->startSection('css'); ?>
  <!-- فایل CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/profile-page.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="profile-page">
        <div class="container my-5">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="card shadow-lg">
                        <div class="card-header bg-primary text-white text-center py-4">
                            <h4 class="mb-0">تکمیل پروفایل</h4>
                            <p class="mb-0">لطفاً اطلاعات خود را وارد کنید</p>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(route('profile.complete.store')); ?>">
                                <?php echo csrf_field(); ?>

                                <!-- نام کامل -->
                                <div class="mb-4">
                                    <label for="name" class="form-label">نام کامل</label>
                                    <div class="input-group">
                                        <span class="input-icon"><i class="fas fa-user"></i></span>
                                        <input type="text" class="form-control has-icon <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               id="name" name="name" value="<?php echo e(old('name', auth()->user()->name)); ?>" required>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <!-- ایمیل -->
                                <div class="mb-4">
                                    <label for="email" class="form-label">ایمیل</label>
                                    <div class="input-group">
                                        <span class="input-icon"><i class="fas fa-envelope"></i></span>
                                        <input type="email" class="form-control has-icon <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               id="email" name="email" value="<?php echo e(old('email', auth()->user()->email)); ?>" required>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <!-- شماره تلفن -->
                                <div class="mb-4">
                                    <label for="phone" class="form-label">شماره تماس</label>
                                    <input type="text" class="form-control" id="phone" value="<?php echo e(auth()->user()->phone_number); ?>" disabled>
                                </div>

                                <!-- دکمه ارسال -->
                                <button type="submit" class="btn btn-success w-100 py-2">ثبت و ادامه</button>
                            </form>
                        </div>
                        <div class="card-footer text-center py-3">
                            <p class="text-muted mb-0">اگر قبلاً اطلاعات خود را وارد کرده‌اید، می‌توانید وارد حساب خود شوید.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sms_laravel\resources\views/profile/complete.blade.php ENDPATH**/ ?>