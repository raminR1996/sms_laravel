

<?php $__env->startSection('title',  ' مدیریت بسته‌های شارژ'); ?>

<?php $__env->startSection('content'); ?>
    <div class="dashboard-page">
                    <!-- فراخوانی کامپوننت نان بری -->
    <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
        <div class="container">
            <h1 class="text-center mb-4">مدیریت بسته‌های شارژ</h1>
            <div class="card mb-4">
                <div class="card-body">
                    <a href="<?php echo e(route('admin.packages.create')); ?>" class="btn btn-primary">ایجاد بسته جدید</a>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>تعداد پیامک</th>
                                <th>قیمت (تومان)</th>
                                <th>وضعیت</th>
                                <th>عملیات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($package->sms_count); ?></td>
                                    <td><?php echo e(number_format($package->price)); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('admin.packages.toggle', $package)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn <?php echo e($package->is_active ? 'btn-success' : 'btn-secondary'); ?>">
                                                <?php echo e($package->is_active ? 'فعال' : 'غیرفعال'); ?>

                                            </button>
                                        </form>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.packages.edit', $package)); ?>" class="btn btn-warning btn-icon">
                                            <i class="fas fa-edit"></i> ویرایش
                                        </a>
                                        <form action="<?php echo e(route('admin.packages.destroy', $package)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-icon" onclick="return confirm('آیا مطمئن هستید؟')">
                                                <i class="fas fa-trash"></i> حذف
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sms_laravel\resources\views/admin/packages/index.blade.php ENDPATH**/ ?>