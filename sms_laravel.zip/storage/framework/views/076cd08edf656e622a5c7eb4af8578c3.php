

<?php $__env->startSection('title',  ' شارژ پنل'); ?>

<?php $__env->startSection('content'); ?>
    <div class="dashboard-page">
        <div class="container">
            <h1 class="text-center mb-4">شارژ پنل</h1>

            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <!-- لیست بسته‌ها -->
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title">انتخاب بسته شارژ</h5>
                    <p class="text-warning mb-3">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        هشدار: هر پیامک برابر با 70 کاراکتر است.
                    </p>
                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-md-4 mb-3">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <h6><?php echo e($package->sms_count); ?> پیامک</h6>
                                        <p><?php echo e(number_format($package->price)); ?> تومان</p>
                                        <form action="<?php echo e(route('payment.purchase')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="package_id" value="<?php echo e($package->id); ?>">
                                            <button type="submit" class="btn btn-primary">خرید</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-12">
                                <p class="text-center">هیچ بسته‌ای در دسترس نیست.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- لیست پرداخت‌های موفق -->
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title">پرداخت‌های موفق</h5>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>مبلغ (تومان)</th>
                                <th>شناسه تراکنش</th>
                                <th>تاریخ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(number_format($payment->amount)); ?></td>
                                    <td><?php echo e($payment->transaction_id); ?></td>
                                    <td><?php echo e($payment->created_at->format('Y-m-d H:i')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" class="text-center">هیچ پرداختی ثبت نشده است.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- لیست بسته‌های خریداری‌شده -->
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">بسته‌های خریداری‌شده</h5>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>تعداد پیامک</th>
                                <th>مبلغ (تومان)</th>
                                <th>تاریخ خرید</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $userPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userPackage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($userPackage->sms_count); ?></td>
                                    <td><?php echo e(number_format($userPackage->price)); ?></td>
                                    <td><?php echo e($userPackage->created_at->format('Y-m-d H:i')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" class="text-center">هیچ بسته‌ای خریداری نشده است.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.querySelectorAll('form button[type="submit"]').forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                Swal.fire({
                    title: 'هشدار',
                    text: 'هر پیامک برابر با 70 کاراکتر است. آیا ادامه می‌دهید؟',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'بله',
                    cancelButtonText: 'خیر',
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.form.submit();
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sms_laravel\resources\views/user/charge.blade.php ENDPATH**/ ?>