

<?php $__env->startSection('title', 'تنظیمات سایت'); ?>

<?php $__env->startSection('css'); ?>
  <!-- فایل CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/settings-page.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- اضافه کردن Font Awesome برای آیکون‌ها -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<!-- اضافه کردن کلاس settings-page به بدنه یا یک دیو -->
<div class="settings-page">
    <!-- فراخوانی کامپوننت نان بری -->
    <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>

    <div class="container settings-container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="settings-card">
                    <div class="settings-card-header">
                        <h1>مدیریت تنظیمات سایت</h1>
                        <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> بازگشت به داشبورد
                        </a>
                    </div>

                    <?php if(session('success')): ?>
                        <div class="alert alert-success text-center"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>

                    <a href="<?php echo e(route('admin.settings.create')); ?>" class="btn btn-primary mb-3">
                        <i class="fas fa-plus"></i> افزودن تنظیمات جدید
                    </a>

                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>کلید</th>
                                    <th>مقدار</th>
                                    <th>عملیات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($setting->key); ?></td>
                                        <td><?php echo e(Str::limit($setting->value, 50)); ?></td>
                                     <td class="action-buttons">
    <a href="<?php echo e(route('admin.settings.edit', $setting->id)); ?>" class="btn btn-icon btn-warning" title="ویرایش تنظیم">
        <i class="fas fa-edit"></i>
    </a>
    <form action="<?php echo e(route('admin.settings.destroy', $setting->id)); ?>" method="POST" style="display:inline;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-icon btn-danger" title="حذف تنظیم" onclick="return confirm('آیا مطمئن هستید؟')">
            <i class="fas fa-trash"></i>
        </button>
    </form>
</td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="3" class="text-center">هیچ تنظیماتی یافت نشد.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sms_laravel\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>