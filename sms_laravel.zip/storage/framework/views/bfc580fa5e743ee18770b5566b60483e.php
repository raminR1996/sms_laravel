<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نتیجه پرداخت</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Arial', sans-serif; direction: rtl; background-color: #f8f9fa; }
        .container { max-width: 600px; margin: 50px auto; }
        .alert { text-align: center; }
        .btn-back { margin-top: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center mb-4">نتیجه پرداخت</h1>

        <?php if(isset($success)): ?>
            <div class="alert alert-success">
                <?php echo e($success); ?>

            </div>
        <?php elseif(isset($error)): ?>
            <div class="alert alert-danger">
                <?php echo e($error); ?>

            </div>
        <?php else: ?>
            <div class="alert alert-warning">
                وضعیت پرداخت نامشخص است.
            </div>
        <?php endif; ?>

        <div class="text-center">
            <a href="<?php echo e(route('charge.index')); ?>" class="btn btn-primary btn-back">بازگشت به صفحه شارژ</a>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\sms_laravel\resources\views/user/callback.blade.php ENDPATH**/ ?>