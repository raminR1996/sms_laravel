<div class="d-flex align-items-center gap-2">
    <!-- دکمه به‌روزرسانی وضعیت -->
    <a href="<?php echo e(route('reports.update.status', $report->id)); ?>" class="btn btn-info btn-sm" title="به‌روزرسانی وضعیت">
        <i class="fas fa-sync-alt"></i>
    </a>
    <!-- دکمه نمایش شماره‌ها و وضعیت‌ها -->
    <button type="button" class="btn btn-secondary btn-sm show-status-modal" 
            data-report-id="<?php echo e($report->id); ?>"
            data-numbers="<?php echo e(json_encode($report->numbers)); ?>"
            data-statuses="<?php echo e(json_encode($report->statuses)); ?>"
            data-datetimes="<?php echo e(json_encode($report->datetimes)); ?>"
            title="مشاهده شماره‌ها و وضعیت">
        <i class="fas fa-eye"></i>
    </button>
</div><?php /**PATH C:\xampp\htdocs\sms_laravel\resources\views/user/sms/reports/actions.blade.php ENDPATH**/ ?>