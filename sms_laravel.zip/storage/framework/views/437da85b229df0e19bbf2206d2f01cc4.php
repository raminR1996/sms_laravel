<a href="<?php echo e(route('admin.contacts.village', $village->id)); ?>" class="btn btn-info btn-icon" title="مشاهده شماره‌ها">
    <i class="fas fa-eye"></i>
</a><?php /**PATH C:\xampp\htdocs\sms_laravel\resources\views/admin/contacts/actions.blade.php ENDPATH**/ ?>