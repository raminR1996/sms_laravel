<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item['active']): ?>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($item['title']); ?></li>
            <?php else: ?>
                <li class="breadcrumb-item"><a href="<?php echo e($item['url']); ?>"><?php echo e($item['title']); ?></a></li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</nav><?php /**PATH C:\xampp\htdocs\sms_laravel\resources\views/components/breadcrumb.blade.php ENDPATH**/ ?>