

<?php $__env->startSection('title', '  ویرایش بسته شارژ'); ?>

<?php $__env->startSection('content'); ?>
    <div class="dashboard-page">
                    <!-- فراخوانی کامپوننت نان بری -->
    <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
        <div class="container">
            <h1 class="text-center mb-4">ویرایش بسته شارژ</h1>
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('admin.packages.update', $package)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group mb-3">
                            <label for="sms_count">تعداد پیامک</label>
                            <select name="sms_count" id="sms_count" class="form-control" required>
                                <option value="100" <?php echo e($package->sms_count == 100 ? 'selected' : ''); ?>>100 پیامک</option>
                                <option value="500" <?php echo e($package->sms_count == 500 ? 'selected' : ''); ?>>500 پیامک</option>
                                <option value="1000" <?php echo e($package->sms_count == 1000 ? 'selected' : ''); ?>>1000 پیامک</option>
                                <option value="5000" <?php echo e($package->sms_count == 5000 ? 'selected' : ''); ?>>5000 پیامک</option>
                                <option value="10000" <?php echo e($package->sms_count == 10000 ? 'selected' : ''); ?>>10000 پیامک</option>
                                <option value="50000" <?php echo e($package->sms_count == 50000 ? 'selected' : ''); ?>>50000 پیامک</option>
                            </select>
                            <?php $__errorArgs = ['sms_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group mb-3">
                            <label for="is_active">وضعیت</label>
                            <select name="is_active" id="is_active" class="form-control">
                                <option value="1" <?php echo e($package->is_active ? 'selected' : ''); ?>>فعال</option>
                                <option value="0" <?php echo e(!$package->is_active ? 'selected' : ''); ?>>غیرفعال</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">به‌روزرسانی بسته</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sms_laravel\resources\views/admin/packages/edit.blade.php ENDPATH**/ ?>