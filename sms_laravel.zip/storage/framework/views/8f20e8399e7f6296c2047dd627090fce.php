

<?php $__env->startSection('title', 'ارسال پیامک تکی'); ?>

<?php $__env->startSection('css'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<style>
    .select2-container {
        width: 100% !important;
    }
    .select2-selection--multiple, .select2-selection--single {
        min-height: 38px !important;
        border: 1px solid #ced4da !important;
        border-radius: 0.375rem !important;
    }
    .select2-selection__choice {
        background-color: #007bff !important;
        color: #fff !important;
        border: none !important;
    }
    .select2-selection__choice__remove {
        color: #fff !important;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="text-center mb-4">ارسال پیامک تکی</h1>
    <div class="card">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('send.sms.single.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="line_number" class="form-label">شماره خط ارسالی:</label>
                    <select name="line_number" id="line_number" class="form-control select2" required>
                        <option value="" disabled selected>یک خط انتخاب کنید</option>
                        <?php $__currentLoopData = \App\Models\Line::where('is_active', true)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($line->line_number); ?>"><?php echo e($line->line_number); ?> (<?php echo e($line->operator_name); ?>)</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['line_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="numbers" class="form-label">شماره‌ها (چندین شماره را با Enter جدا کنید):</label>
                    <select name="numbers[]" id="numbers" class="form-control select2" multiple="multiple" required>
                    </select>
                    <?php $__errorArgs = ['numbers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="message" class="form-label">متن پیامک:</label>
                    <textarea name="message" id="message" class="form-control" rows="5" required oninput="calculateSmsCount()"></textarea>
                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label>تعداد پیامک‌ها: </label>
                    <span id="sms-count">0</span>
                </div>

                <div class="mb-3">
                    <label>مانده اعتبار: </label>
                    <span id="balance"><?php echo e(auth()->user()->sms_balance ?? 0); ?></span> پیامک
                </div>

                <button type="submit" class="btn btn-primary">ارسال</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('#numbers').select2({
            tags: true,
            tokenSeparators: [',', '\n'],
            placeholder: "شماره‌ها را وارد کنید (مثال: 09123456789)",
            allowClear: true
        });

        $('#line_number').select2({
            placeholder: "یک خط انتخاب کنید",
            allowClear: true
        });
    });

    function calculateSmsCount() {
        const message = document.getElementById('message').value;
        const isPersian = /[\u0600-\u06FF]/.test(message);
        const smsLength = isPersian ? 70 : 160;
        const messageLength = message.length;
        const smsCount = Math.ceil(messageLength / smsLength);
        document.getElementById('sms-count').innerText = smsCount;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sms_laravel\resources\views/user/sms/send-single.blade.php ENDPATH**/ ?>