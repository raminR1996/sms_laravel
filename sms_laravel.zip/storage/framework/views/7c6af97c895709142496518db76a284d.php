

<?php $__env->startSection('title', 'ورود به پنل'); ?>

<?php $__env->startSection('content'); ?>
    <h3>ورود به پنل</h3>
    <p class="subtitle">OTP ارسال</p>

    <?php if(session('success')): ?>
        <div class="alert alert-success text-center"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('otp.send')); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-4">
            <label for="phone_number" class="form-label">شماره همراه</label>
            <input type="text"
                   class="form-control <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   id="phone_number"
                   name="phone_number"
                   placeholder="09123456789"
                   required>
            <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-check mb-4">
            <input class="form-check-input" type="checkbox" id="remember_me" name="remember_me">
            <label class="form-check-label" for="remember_me">مرا به خاطر بسپار</label>
        </div>

        <button type="submit" class="btn btn-primary">ورود</button>
    </form>

    <p class="signup-link">
        حساب کاربری ندارید؟ <a href="#">ثبت‌نام</a>
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sms_laravel\resources\views/auth/otp-login.blade.php ENDPATH**/ ?>