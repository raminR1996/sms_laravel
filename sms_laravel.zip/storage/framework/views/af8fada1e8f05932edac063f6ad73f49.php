

<?php $__env->startSection('title', 'تأیید کد'); ?>

<?php $__env->startSection('content'); ?>
    <h3>تأیید کد</h3>
    <p class="subtitle">کدی که به شماره <?php echo e(session('phone_number')); ?> ارسال شده را وارد کنید</p>

    <?php if(session('success')): ?>
        <div class="alert alert-success text-center"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger text-center"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('otp.verify.post')); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-4">
            <label for="code" class="form-label">کد تأیید</label>
            <input type="text"
                   id="code"
                   name="code"
                   class="form-control <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   placeholder="123456"
                   required>
            <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="btn btn-primary">تأیید</button>
    </form>

    <p class="signup-link">
        کدی دریافت نکردید؟
        <form method="POST" action="<?php echo e(route('otp.send')); ?>" style="display: inline;">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="phone_number" value="<?php echo e(session('phone_number')); ?>">
            <button type="submit" class="btn btn-link p-0" style="color: #4a90e2; text-decoration: none;">ارسال مجدد</button>
        </form>
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sms_laravel\resources\views/auth/otp-verify.blade.php ENDPATH**/ ?>